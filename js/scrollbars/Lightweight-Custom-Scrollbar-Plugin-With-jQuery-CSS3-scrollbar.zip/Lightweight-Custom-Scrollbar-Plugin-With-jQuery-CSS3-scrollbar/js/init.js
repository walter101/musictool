$(function(){
	$('.example').makeScroll();
});