ekScroll
================================

Erwan Kuznik

http://www.wdev.pro


What is ekScroll?
------------------
ekScroll is a very simple jQuery plugin to create scroll bar in html element.

It depends on jQuery UI / Draggable and jquery.mousewheel.js (https://github.com/brandonaaron)



How to use it:
------------------
Include the scripts in your page.

HTML :
<div class="scrollabledivclass">
  long content here
</div>

JS :
$('.scrollabledivclass').ekScrollable();


That's it.


A LESS file is included to allow you to easily customize the scroll bars. Your can even have different scrollbars looks on a single page. 


If you like the plugin, any tip is welcome:

BTC: 1Lr9KurDVTYwfm5JtjAVR5xjPwqUH82csG
